export { empty }    from './empty/empty';
export { forEach }  from './forEach/forEach';
export { includes } from './includes/includes';
export { push }     from './push/push';
export { toArray }  from './toArray/toArray';

export const arrayProto = Array.prototype;
